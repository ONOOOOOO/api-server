import { Router, type IRouter } from "express";
import nodemailer from "nodemailer";
import { SimulateTransferBody, SimulateTransferResponse } from "@workspace/api-zod";
import { randomUUID } from "crypto";

const router: IRouter = Router();

router.post("/transfer", async (req, res) => {
  const parseResult = SimulateTransferBody.safeParse(req.body);

  if (!parseResult.success) {
    res.status(400).json({ success: false, error: "Données invalides : " + parseResult.error.message });
    return;
  }

  const { recipient, account, bank, amount, currency, email } = parseResult.data;
  const referenceId = "TRF-" + randomUUID().slice(0, 8).toUpperCase();
  const currencySymbol = currency === "EUR" ? "€" : currency === "USD" ? "$" : "£";

  const gmailUser = process.env["GMAIL_USER"];
  const gmailPass = process.env["GMAIL_APP_PASSWORD"];

  if (gmailUser && gmailPass) {
    try {
      const transporter = nodemailer.createTransport({
        service: "gmail",
        auth: {
          user: gmailUser,
          pass: gmailPass,
        },
      });

      const htmlBody = `<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Notification de transfert</title>
</head>
<body style="margin:0;padding:0;background-color:#f4f6f9;font-family:'Segoe UI',Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background-color:#f4f6f9;padding:40px 0;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">

          <!-- Header -->
          <tr>
            <td style="background:linear-gradient(135deg,#1a237e 0%,#283593 100%);padding:32px 40px;text-align:center;">
              <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;letter-spacing:1px;">🏦 Nova Bank</h1>
              <p style="margin:6px 0 0;color:#c5cae9;font-size:13px;letter-spacing:0.5px;">SIMULATEUR BANCAIRE — FINTECH</p>
            </td>
          </tr>

          <!-- Alert Banner -->
          <tr>
            <td style="background:#fff3e0;border-bottom:3px solid #ff6f00;padding:20px 40px;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="width:48px;vertical-align:middle;">
                    <div style="width:44px;height:44px;background:#ff6f00;border-radius:50%;text-align:center;line-height:44px;font-size:22px;">⚠️</div>
                  </td>
                  <td style="padding-left:16px;vertical-align:middle;">
                    <p style="margin:0;font-size:18px;font-weight:700;color:#e65100;">Transfert bloqué</p>
                    <p style="margin:4px 0 0;font-size:13px;color:#bf360c;">Limite journalière atteinte — action requise</p>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Body -->
          <tr>
            <td style="padding:36px 40px;">
              <p style="margin:0 0 8px;font-size:15px;color:#37474f;">Bonjour,</p>
              <p style="margin:0 0 28px;font-size:15px;color:#37474f;line-height:1.6;">
                Votre demande de transfert a été <strong style="color:#e65100;">bloquée automatiquement</strong> car vous avez atteint la limite de transfert autorisée pour aujourd'hui. Voici le récapitulatif de l'opération concernée :
              </p>

              <!-- Details Card -->
              <table width="100%" cellpadding="0" cellspacing="0" style="background:#f8fafc;border:1px solid #e3e8ef;border-radius:10px;overflow:hidden;margin-bottom:28px;">
                <tr style="background:#e8eaf6;">
                  <td colspan="2" style="padding:14px 20px;">
                    <p style="margin:0;font-size:12px;font-weight:700;color:#3949ab;letter-spacing:1px;text-transform:uppercase;">Détails du transfert</p>
                  </td>
                </tr>
                <tr>
                  <td style="padding:14px 20px;font-size:13px;color:#78909c;border-bottom:1px solid #e3e8ef;width:45%;">Référence</td>
                  <td style="padding:14px 20px;font-size:13px;font-weight:700;color:#263238;border-bottom:1px solid #e3e8ef;font-family:monospace;">${referenceId}</td>
                </tr>
                <tr>
                  <td style="padding:14px 20px;font-size:13px;color:#78909c;border-bottom:1px solid #e3e8ef;">Bénéficiaire</td>
                  <td style="padding:14px 20px;font-size:13px;font-weight:600;color:#263238;border-bottom:1px solid #e3e8ef;">${recipient}</td>
                </tr>
                <tr>
                  <td style="padding:14px 20px;font-size:13px;color:#78909c;border-bottom:1px solid #e3e8ef;">Numéro de compte</td>
                  <td style="padding:14px 20px;font-size:13px;font-weight:600;color:#263238;border-bottom:1px solid #e3e8ef;font-family:monospace;">${account}</td>
                </tr>
                <tr>
                  <td style="padding:14px 20px;font-size:13px;color:#78909c;border-bottom:1px solid #e3e8ef;">Banque</td>
                  <td style="padding:14px 20px;font-size:13px;font-weight:600;color:#263238;border-bottom:1px solid #e3e8ef;">${bank}</td>
                </tr>
                <tr>
                  <td style="padding:14px 20px;font-size:13px;color:#78909c;">Montant</td>
                  <td style="padding:14px 20px;font-size:16px;font-weight:800;color:#e65100;">${currencySymbol}${Number(amount).toFixed(2)} ${currency}</td>
                </tr>
              </table>

              <!-- Status Badge -->
              <table cellpadding="0" cellspacing="0" style="margin-bottom:28px;">
                <tr>
                  <td style="background:#fbe9e7;border:1px solid #ffccbc;border-radius:8px;padding:10px 20px;">
                    <span style="font-size:13px;font-weight:700;color:#bf360c;">🔒 STATUT : TRANSFERT BLOQUÉ — LIMITE ATTEINTE</span>
                  </td>
                </tr>
              </table>

              <p style="margin:0 0 8px;font-size:14px;color:#37474f;line-height:1.6;">
                Pour débloquer votre accès ou augmenter votre limite, veuillez contacter votre conseiller bancaire ou vous connecter à votre espace client.
              </p>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="background:#f4f6f9;border-top:1px solid #e3e8ef;padding:24px 40px;text-align:center;">
              <p style="margin:0 0 6px;font-size:12px;color:#90a4ae;">Ce message est généré automatiquement dans le cadre d'un <strong>simulateur bancaire pédagogique</strong>.</p>
              <p style="margin:0;font-size:11px;color:#b0bec5;">Aucune transaction réelle n'a été effectuée. © Nova Bank Simulator</p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;

      await transporter.sendMail({
        from: `"Nova Bank" <${gmailUser}>`,
        to: email,
        subject: `⚠️ Transfert bloqué — Limite atteinte [${referenceId}]`,
        html: htmlBody,
      });

      req.log.info({ referenceId, recipient, bank, amount, currency }, "Transfer simulated, email sent");
    } catch (emailErr) {
      req.log.warn({ err: emailErr }, "Transfer simulated but email failed to send");
    }
  } else {
    req.log.warn("GMAIL credentials not configured — email not sent");
  }

  const response = SimulateTransferResponse.parse({
    success: true,
    message: `Transfert simulé de ${currencySymbol}${Number(amount).toFixed(2)} ${currency} vers ${recipient} effectué avec succès.`,
    referenceId,
  });

  res.json(response);
});

export default router;
