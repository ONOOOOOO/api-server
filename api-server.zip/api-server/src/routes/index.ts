import { Router, type IRouter } from "express";
import healthRouter from "./health";
import transferRouter from "./transfer";

const router: IRouter = Router();

router.use(healthRouter);
router.use(transferRouter);

export default router;
